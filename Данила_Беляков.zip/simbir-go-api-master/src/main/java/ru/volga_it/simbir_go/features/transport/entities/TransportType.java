package ru.volga_it.simbir_go.features.transport.entities;

public enum TransportType {
    Car, Bike, Scooter
}
