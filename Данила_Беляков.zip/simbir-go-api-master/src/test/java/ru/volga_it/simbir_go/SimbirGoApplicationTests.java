package ru.volga_it.simbir_go;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimbirGoApplicationTests {

    @Test
    void contextLoads() {
    }

}
