package ru.volga_it.simbir_go.common.validation;

public interface OnUpdate { }
