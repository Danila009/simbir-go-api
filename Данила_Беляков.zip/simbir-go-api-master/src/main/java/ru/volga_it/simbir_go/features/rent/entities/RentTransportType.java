package ru.volga_it.simbir_go.features.rent.entities;

public enum RentTransportType {
    Minutes, Days
}
